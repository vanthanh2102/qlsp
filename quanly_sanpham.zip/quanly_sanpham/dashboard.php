<?php
session_start();
require_once 'config.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Thống kê tổng quan
$stats_sql = "SELECT 
    COUNT(*) as total_products,
    SUM(price * quantity) as total_value,
    COUNT(CASE WHEN quantity < 10 THEN 1 END) as low_stock,
    AVG(price) as avg_price
FROM products";
$stats_result = mysqli_query($conn, $stats_sql);
$stats = mysqli_fetch_assoc($stats_result);

// Thống kê theo danh mục
$category_sql = "SELECT 
    c.name,
    COUNT(p.id) as product_count,
    SUM(p.quantity) as total_quantity,
    SUM(p.price * p.quantity) as total_value
FROM categories c
LEFT JOIN products p ON c.id = p.category_id
GROUP BY c.id
ORDER BY total_value DESC
LIMIT 5";
$category_result = mysqli_query($conn, $category_sql);

// Sản phẩm sắp hết hàng
$low_stock_sql = "SELECT p.*, c.name as category_name
FROM products p
LEFT JOIN categories c ON p.category_id = c.id
WHERE p.quantity < 10
ORDER BY p.quantity ASC
LIMIT 5";
$low_stock_result = mysqli_query($conn, $low_stock_sql);

// Sản phẩm giá trị cao nhất
$top_value_sql = "SELECT p.*, c.name as category_name,
(p.price * p.quantity) as total_value
FROM products p
LEFT JOIN categories c ON p.category_id = c.id
ORDER BY total_value DESC
LIMIT 5";
$top_value_result = mysqli_query($conn, $top_value_sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Thống kê - Quản lý sản phẩm</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <!-- Animation CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Loading Animation -->
    <div class="loading">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <!-- Header -->
    <div class="header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h2><i class="fas fa-chart-bar"></i> Thống kê</h2>
                </div>
                <div class="col-md-6 text-right">
                    <div class="user-info">
                        <span class="mr-2">
                            <i class="fas fa-user"></i> 
                            <?php echo htmlspecialchars($_SESSION['username']); ?>
                        </span>
                        <a href="logout.php" class="btn btn-light btn-sm">
                            <i class="fas fa-sign-out-alt"></i> Đăng xuất
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <!-- Thống kê tổng quan -->
        <div class="row">
            <div class="col-md-3">
                <div class="card bg-primary text-white mb-4 animate__animated animate__fadeIn">
                    <div class="card-body">
                        <h5><i class="fas fa-boxes"></i> Tổng sản phẩm</h5>
                        <h2><?php echo number_format($stats['total_products']); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white mb-4 animate__animated animate__fadeIn">
                    <div class="card-body">
                        <h5><i class="fas fa-money-bill"></i> Tổng giá trị</h5>
                        <h2><?php echo number_format($stats['total_value']); ?> VNĐ</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-white mb-4 animate__animated animate__fadeIn">
                    <div class="card-body">
                        <h5><i class="fas fa-exclamation-triangle"></i> Sắp hết hàng</h5>
                        <h2><?php echo number_format($stats['low_stock']); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info text-white mb-4 animate__animated animate__fadeIn">
                    <div class="card-body">
                        <h5><i class="fas fa-tag"></i> Giá trung bình</h5>
                        <h2><?php echo number_format($stats['avg_price']); ?> VNĐ</h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Biểu đồ và bảng thống kê -->
        <div class="row">
            <!-- Biểu đồ phân bố theo danh mục -->
            <div class="col-md-6">
                <div class="card mb-4 animate__animated animate__fadeIn">
                    <div class="card-header">
                        <h5><i class="fas fa-chart-pie"></i> Phân bố theo danh mục</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="categoryChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Bảng sản phẩm sắp hết hàng -->
            <div class="col-md-6">
                <div class="card mb-4 animate__animated animate__fadeIn">
                    <div class="card-header">
                        <h5><i class="fas fa-exclamation-triangle"></i> Sản phẩm sắp hết hàng</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Sản phẩm</th>
                                        <th>Danh mục</th>
                                        <th>Số lượng</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($product = mysqli_fetch_assoc($low_stock_result)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                                            <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                                            <td>
                                                <span class="badge badge-danger">
                                                    <?php echo $product['quantity']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="edit.php?id=<?php echo $product['id']; ?>" 
                                                   class="btn btn-warning btn-sm">
                                                    <i class="fas fa-edit"></i> Cập nhật
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bảng thống kê chi tiết -->
        <div class="card mb-4 animate__animated animate__fadeIn">
            <div class="card-header">
                <h5><i class="fas fa-table"></i> Thống kê theo danh mục</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Danh mục</th>
                                <th>Số sản phẩm</th>
                                <th>Tổng số lượng</th>
                                <th>Tổng giá trị</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            mysqli_data_seek($category_result, 0);
                            while($category = mysqli_fetch_assoc($category_result)): 
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($category['name']); ?></td>
                                    <td><?php echo number_format($category['product_count']); ?></td>
                                    <td><?php echo number_format($category['total_quantity']); ?></td>
                                    <td><?php echo number_format($category['total_value']); ?> VNĐ</td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="text-center mb-4">
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Quay lại
            </a>
            <a href="export.php" class="btn btn-success">
                <i class="fas fa-file-export"></i> Xuất báo cáo
            </a>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>

    <!-- Chart.js Script -->
    <script>
        // Dữ liệu cho biểu đồ danh mục
        <?php
        mysqli_data_seek($category_result, 0);
        $labels = [];
        $data = [];
        while($category = mysqli_fetch_assoc($category_result)) {
            $labels[] = $category['name'];
            $data[] = $category['total_value'];
        }
        ?>

        var ctx = document.getElementById('categoryChart').getContext('2d');
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($data); ?>,
                    backgroundColor: [
                        '#4e73df',
                        '#1cc88a',
                        '#36b9cc',
                        '#f6c23e',
                        '#e74a3b'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    position: 'bottom'
                }
            }
        });
    </script>
</body>
</html>