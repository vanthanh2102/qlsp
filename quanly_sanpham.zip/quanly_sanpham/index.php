<?php
session_start();
require_once 'config.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Số sản phẩm trên mỗi trang
$items_per_page = 10;

// Lấy trang hiện tại
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $items_per_page;

// Xây dựng câu truy vấn với điều kiện lọc
$where_conditions = [];
$params = [];
$types = "";

if (isset($_GET['category']) && !empty($_GET['category'])) {
    $where_conditions[] = "p.category_id = ?";
    $params[] = $_GET['category'];
    $types .= "i";
}

if (isset($_GET['price_from']) && !empty($_GET['price_from'])) {
    $where_conditions[] = "p.price >= ?";
    $params[] = $_GET['price_from'];
    $types .= "d";
}

if (isset($_GET['price_to']) && !empty($_GET['price_to'])) {
    $where_conditions[] = "p.price <= ?";
    $params[] = $_GET['price_to'];
    $types .= "d";
}

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $where_conditions[] = "(p.name LIKE ? OR p.description LIKE ?)";
    $search_term = "%" . $_GET['search'] . "%";
    $params[] = $search_term;
    $params[] = $search_term;
    $types .= "ss";
}

$where_clause = !empty($where_conditions) ? " WHERE " . implode(" AND ", $where_conditions) : "";

// Lấy tổng số sản phẩm và doanh thu
$stats_sql = "SELECT 
    COUNT(*) as total_products,
    COALESCE(SUM(price * quantity), 0) as total_value,
    COUNT(CASE WHEN quantity < 10 THEN 1 END) as low_stock
FROM products";
$stats_result = mysqli_query($conn, $stats_sql);
if ($stats_result) {
    $stats = mysqli_fetch_assoc($stats_result);
} else {
    $stats = [
        'total_products' => 0,
        'total_value' => 0,
        'low_stock' => 0
    ];
}

// Lấy danh sách sản phẩm
$sql = "SELECT p.*, c.name as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id" . 
        $where_clause . 
        " ORDER BY p.id DESC LIMIT ? OFFSET ?";

$stmt = mysqli_prepare($conn, $sql);

if ($stmt) {
    // Thêm LIMIT và OFFSET vào params
    $types .= "ii";
    $params[] = $items_per_page;
    $params[] = $offset;
    
    if (!empty($params)) {
        $bind_params = array();
        $bind_params[] = &$types;
        
        foreach ($params as $key => $value) {
            $bind_params[] = &$params[$key];
        }
        
        if (!call_user_func_array(array($stmt, 'bind_param'), $bind_params)) {
            die("Lỗi bind param: " . mysqli_stmt_error($stmt));
        }
    }
    
    if (!mysqli_stmt_execute($stmt)) {
        die("Lỗi thực thi: " . mysqli_stmt_error($stmt));
    }
    
    $result = mysqli_stmt_get_result($stmt);
    if ($result === false) {
        die("Lỗi lấy kết quả: " . mysqli_error($conn));
    }
} else {
    die("Lỗi chuẩn bị câu lệnh: " . mysqli_error($conn));
}

// Đếm tổng số sản phẩm cho phân trang
$count_sql = "SELECT COUNT(*) as total FROM products p" . $where_clause;
$count_stmt = mysqli_prepare($conn, $count_sql);

if ($count_stmt) {
    if (!empty($params)) {
        // Bỏ 2 tham số cuối (LIMIT và OFFSET)
        $count_types = substr($types, 0, -2);
        $count_params = array_slice($params, 0, -2);
        
        if (!empty($count_params)) {
            $bind_count_params = array();
            $bind_count_params[] = &$count_types;
            
            foreach ($count_params as $key => $value) {
                $bind_count_params[] = &$count_params[$key];
            }
            
            call_user_func_array(array($count_stmt, 'bind_param'), $bind_count_params);
        }
    }
    
    mysqli_stmt_execute($count_stmt);
    $count_result = mysqli_stmt_get_result($count_stmt);
    $total_items = mysqli_fetch_assoc($count_result)['total'];
    mysqli_stmt_close($count_stmt);
} else {
    $total_items = 0;
}

$total_pages = ceil($total_items / $items_per_page);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Quản lý sản phẩm</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h2><i class="fas fa-boxes"></i> Quản lý sản phẩm</h2>
                </div>
                <div class="col-md-6 text-right">
                    <div class="user-info">
                        <span class="mr-2">
                            <i class="fas fa-user"></i> 
                            <?php echo htmlspecialchars($_SESSION['username']); ?>
                        </span>
                        <a href="logout.php" class="btn btn-light btn-sm">
                            <i class="fas fa-sign-out-alt"></i> Đăng xuất
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <!-- Thống kê -->
        <div class="row stats-cards">
            <div class="col-md-4">
                <div class="stats-card bg-info-light">
                    <h3><?php echo number_format($stats['total_products']); ?></h3>
                    <p>Tổng số sản phẩm</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stats-card bg-success-light">
                    <h3><?php echo number_format($stats['total_value']); ?> VNĐ</h3>
                    <p>Tổng giá trị</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stats-card bg-warning-light">
                    <h3><?php echo number_format($stats['low_stock']); ?></h3>
                    <p>Sản phẩm sắp hết</p>
                </div>
            </div>
        </div>

        <!-- Form lọc và tìm kiếm -->
        <div class="card mb-4">
            <div class="card-header">
                <h5><i class="fas fa-filter"></i> Lọc sản phẩm</h5>
            </div>
            <div class="card-body">
                <form method="GET" class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Danh mục</label>
                            <select name="category" class="form-control">
                                <option value="">Tất cả danh mục</option>
                                <?php
                                $categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");
                                if ($categories) {
                                    while($cat = mysqli_fetch_assoc($categories)) {
                                        $selected = (isset($_GET['category']) && $_GET['category'] == $cat['id']) ? 'selected' : '';
                                        echo "<option value='{$cat['id']}' {$selected}>{$cat['name']}</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Giá từ</label>
                            <input type="number" name="price_from" class="form-control" value="<?php echo $_GET['price_from'] ?? ''; ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Giá đến</label>
                            <input type="number" name="price_to" class="form-control" value="<?php echo $_GET['price_to'] ?? ''; ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Tìm kiếm</label>
                            <input type="text" name="search" class="form-control" value="<?php echo $_GET['search'] ?? ''; ?>" placeholder="Tên hoặc mô tả...">
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i> Tìm kiếm
                        </button>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-sync"></i> Đặt lại
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Các nút chức năng -->
        <div class="action-buttons mb-4">
            <a href="add.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Thêm sản phẩm
            </a>
            <a href="categories.php" class="btn btn-info">
                <i class="fas fa-list"></i> Quản lý danh mục
            </a>
            <a href="export.php" class="btn btn-success">
                <i class="fas fa-file-export"></i> Xuất báo cáo
            </a>
            <a href="dashboard.php" class="btn btn-warning">
                <i class="fas fa-chart-bar"></i> Thống kê
            </a>
        </div>

        <!-- Bảng danh sách sản phẩm -->
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-list"></i> Danh sách sản phẩm</h5>
            </div>
            <div class="card-body">
                <?php if ($result && mysqli_num_rows($result) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Hình ảnh</th>
                                    <th>Tên sản phẩm</th>
                                    <th>Danh mục</th>
                                    <th>Mô tả</th>
                                    <th>Giá</th>
                                    <th>Số lượng</th>
                                    <th>Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td>
                                            <?php if (!empty($row['image'])): ?>
                                                <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" 
                                                     alt="<?php echo htmlspecialchars($row['name']); ?>"
                                                     class="img-thumbnail"
                                                     style="max-width: 100px;">
                                            <?php else: ?>
                                                <img src="assets/images/no-image.png" 
                                                     alt="No Image"
                                                     class="img-thumbnail"
                                                     style="max-width: 100px;">
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['category_name'] ?? 'Chưa phân loại'); ?></td>
                                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                                        <td><?php echo number_format($row['price']); ?> VNĐ</td>
                                        <td>
                                            <span class="badge <?php echo $row['quantity'] < 10 ? 'badge-danger' : 'badge-success'; ?>">
                                                <?php echo $row['quantity']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">
                                                <i class="fas fa-edit"></i> Sửa
                                            </a>
                                            <a href="delete.php?id=<?php echo $row['id']; ?>" 
                                               class="btn btn-danger btn-sm" 
                                               onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">
                                                <i class="fas fa-trash"></i> Xóa
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Phân trang -->
                    <?php if($total_pages > 1): ?>
                        <nav aria-label="Page navigation" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if($current_page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $current_page-1; ?><?php echo isset($_GET['category']) ? '&category='.$_GET['category'] : ''; ?>">
                                            <i class="fas fa-chevron-left"></i> Trước
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $current_page ? 'active' : '' ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?><?php echo isset($_GET['category']) ? '&category='.$_GET['category'] : ''; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>
                                
                                <?php if($current_page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $current_page+1; ?><?php echo isset($_GET['category']) ? '&category='.$_GET['category'] : ''; ?>">
                                            Sau <i class="fas fa-chevron-right"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="alert alert-info">
                        Không có sản phẩm nào để hiển thị.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
<?php
// Đóng kết nối
if (isset($stmt)) {
    mysqli_stmt_close($stmt);
}
mysqli_close($conn);
?>