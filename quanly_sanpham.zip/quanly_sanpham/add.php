<?php
session_start();
require_once 'config.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Xử lý thêm sản phẩm
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $category_id = $_POST['category_id'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $image = "";
    
    // Xử lý upload ảnh
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['image']['name'];
        $filetype = pathinfo($filename, PATHINFO_EXTENSION);
        
        if(in_array(strtolower($filetype), $allowed)) {
            // Kiểm tra kích thước file (giới hạn 2MB)
            if($_FILES['image']['size'] <= 2097152) {
                // Tạo tên file mới để tránh trùng lặp
                $newname = uniqid() . '.' . $filetype;
                $upload_path = 'uploads/' . $newname;
                
                if(move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                    $image = $newname;
                } else {
                    $_SESSION['error'] = "Lỗi khi upload file.";
                }
            } else {
                $_SESSION['error'] = "File quá lớn. Vui lòng chọn file dưới 2MB.";
            }
        } else {
            $_SESSION['error'] = "Chỉ cho phép file ảnh định dạng: jpg, jpeg, png, gif";
        }
    }

    // Thêm sản phẩm vào database
    $sql = "INSERT INTO products (name, category_id, description, price, quantity, image) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sisdis", $name, $category_id, $description, $price, $quantity, $image);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Thêm sản phẩm thành công!";
        header("Location: index.php");
        exit();
    } else {
        $_SESSION['error'] = "Lỗi: " . mysqli_error($conn);
    }
}

// Lấy danh sách danh mục
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Thêm sản phẩm mới</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-plus"></i> Thêm sản phẩm mới</h5>
            </div>
            <div class="card-body">
                <?php if(isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger">
                        <?php 
                        echo $_SESSION['error']; 
                        unset($_SESSION['error']);
                        ?>
                    </div>
                <?php endif; ?>

                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Tên sản phẩm</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>Danh mục</label>
                        <select name="category_id" class="form-control" required>
                            <option value="">Chọn danh mục</option>
                            <?php while($cat = mysqli_fetch_assoc($categories)): ?>
                                <option value="<?php echo $cat['id']; ?>">
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Mô tả</label>
                        <textarea name="description" class="form-control" rows="3"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Giá</label>
                        <input type="number" name="price" class="form-control" required min="0">
                    </div>

                    <div class="form-group">
                        <label>Số lượng</label>
                        <input type="number" name="quantity" class="form-control" required min="0">
                    </div>

                    <div class="form-group">
                        <label>Hình ảnh</label>
                        <input type="file" name="image" class="form-control-file">
                        <small class="form-text text-muted">
                            Cho phép: JPG, JPEG, PNG, GIF. Tối đa 2MB
                        </small>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Lưu
                        </button>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Quay lại
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>