<?php
session_start();
require_once 'config.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Kiểm tra ID danh mục
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: categories.php");
    exit();
}

$category_id = (int)$_GET['id'];

// Kiểm tra xem danh mục có sản phẩm không
$stmt = mysqli_prepare($conn, "SELECT COUNT(*) as count FROM products WHERE category_id = ?");
mysqli_stmt_bind_param($stmt, "i", $category_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$count = mysqli_fetch_assoc($result)['count'];

if ($count > 0) {
    $_SESSION['error'] = "Không thể xóa danh mục này vì đang có sản phẩm thuộc danh mục!";
    header("Location: categories.php");
    exit();
}

// Thực hiện xóa danh mục
$stmt = mysqli_prepare($conn, "DELETE FROM categories WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $category_id);

if (mysqli_stmt_execute($stmt)) {
    $_SESSION['success'] = "Xóa danh mục thành công!";
} else {
    $_SESSION['error'] = "Lỗi khi xóa danh mục: " . mysqli_error($conn);
}

header("Location: categories.php");
exit();
?> 