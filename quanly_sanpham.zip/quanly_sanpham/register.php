<?php
session_start();
require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    
    // Kiểm tra username đã tồn tại chưa
    $check_sql = "SELECT id FROM users WHERE username = ? OR email = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "ss", $username, $email);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    
    if (mysqli_num_rows($check_result) > 0) {
        $error = "Tên đăng nhập hoặc email đã tồn tại!";
    } else {
        // Mã hóa mật khẩu
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Thêm user mới
        $sql = "INSERT INTO users (username, password, fullname, email, role) VALUES (?, ?, ?, ?, 'staff')";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssss", $username, $hashed_password, $fullname, $email);
        
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success'] = "Đăng ký thành công! Vui lòng đăng nhập.";
            header("Location: login.php");
            exit();
        } else {
            $error = "Có lỗi xảy ra, vui lòng thử lại!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Đăng ký - Quản lý sản phẩm</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <!-- Animation CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
    <!-- Loading Animation -->
    <div class="loading">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <div class="container">
        <div class="register-container animate__animated animate__fadeIn">
            <div class="text-center mb-4">
                <i class="fas fa-user-plus fa-3x text-primary"></i>
                <h2 class="mt-3">Đăng ký tài khoản</h2>
                <p class="text-muted">Tạo tài khoản mới để sử dụng hệ thống</p>
            </div>
            
            <?php if(isset($error)): ?>
                <div class="alert alert-danger animate__animated animate__shake">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="needs-validation" novalidate>
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Tên đăng nhập</label>
                    <input type="text" name="username" class="form-control" required pattern="[A-Za-z0-9]{4,}">
                    <div class="invalid-feedback">
                        Tên đăng nhập phải có ít nhất 4 ký tự và không chứa ký tự đặc biệt
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Mật khẩu</label>
                    <input type="password" name="password" class="form-control" required minlength="6">
                    <div class="invalid-feedback">
                        Mật khẩu phải có ít nhất 6 ký tự
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-user-circle"></i> Họ và tên</label>
                    <input type="text" name="fullname" class="form-control" required>
                    <div class="invalid-feedback">
                        Vui lòng nhập họ và tên
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" name="email" class="form-control" required>
                    <div class="invalid-feedback">
                        Vui lòng nhập email hợp lệ
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block btn-lg">
                    <i class="fas fa-user-plus"></i> Đăng ký
                </button>
            </form>
            
            <div class="text-center mt-4">
                <p class="mb-2">Đã có tài khoản?</p>
                <a href="login.php" class="btn btn-outline-primary">
                    <i class="fas fa-sign-in-alt"></i> Đăng nhập
                </a>
            </div>
        </div>
        
        <footer class="text-center mt-5">
            <p class="text-muted">&copy; <?php echo date('Y'); ?> Quản lý sản phẩm. All rights reserved.</p>
        </footer>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>