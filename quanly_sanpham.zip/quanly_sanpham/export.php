<?php
session_start();
require_once 'config.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Xử lý xuất báo cáo
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy thông tin từ form
    $report_type = $_POST['report_type'];
    $date_from = $_POST['date_from'];
    $date_to = $_POST['date_to'];
    
    // Tạo query dựa trên loại báo cáo
    switch($report_type) {
        case 'inventory':
            $sql = "SELECT p.*, c.name as category_name 
                   FROM products p 
                   LEFT JOIN categories c ON p.category_id = c.id 
                   ORDER BY p.quantity ASC";
            $title = "Báo cáo tồn kho";
            break;
            
        case 'low_stock':
            $sql = "SELECT p.*, c.name as category_name 
                   FROM products p 
                   LEFT JOIN categories c ON p.category_id = c.id 
                   WHERE p.quantity < 10 
                   ORDER BY p.quantity ASC";
            $title = "Báo cáo hàng sắp hết";
            break;
            
        case 'category':
            $sql = "SELECT c.name as category_name, 
                          COUNT(p.id) as total_products,
                          SUM(p.quantity) as total_quantity,
                          SUM(p.price * p.quantity) as total_value
                   FROM categories c
                   LEFT JOIN products p ON c.id = p.category_id
                   GROUP BY c.id
                   ORDER BY total_value DESC";
            $title = "Báo cáo theo danh mục";
            break;
            
        default:
            $_SESSION['error'] = "Loại báo cáo không hợp lệ";
            header("Location: index.php");
            exit();
    }
    
    // Thực hiện query
    $result = mysqli_query($conn, $sql);
    
    // Xuất file Excel
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="' . $title . '.xls"');
    header('Cache-Control: max-age=0');
    
    // Xuất header UTF-8 để hiển thị tiếng Việt
    echo chr(0xEF) . chr(0xBB) . chr(0xBF);
    
    // In tiêu đề báo cáo
    echo $title . "\n";
    echo "Ngày xuất báo cáo: " . date('d/m/Y H:i:s') . "\n\n";
    
    // In header của bảng theo loại báo cáo
    switch($report_type) {
        case 'inventory':
        case 'low_stock':
            echo "ID\tTên sản phẩm\tDanh mục\tGiá\tSố lượng tồn\tGiá trị tồn kho\n";
            while($row = mysqli_fetch_assoc($result)) {
                echo $row['id'] . "\t";
                echo $row['name'] . "\t";
                echo $row['category_name'] . "\t";
                echo number_format($row['price']) . "\t";
                echo $row['quantity'] . "\t";
                echo number_format($row['price'] * $row['quantity']) . "\n";
            }
            break;
            
        case 'category':
            echo "Danh mục\tSố sản phẩm\tTổng số lượng\tTổng giá trị\n";
            while($row = mysqli_fetch_assoc($result)) {
                echo $row['category_name'] . "\t";
                echo $row['total_products'] . "\t";
                echo $row['total_quantity'] . "\t";
                echo number_format($row['total_value']) . "\n";
            }
            break;
    }
    
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Xuất báo cáo - Quản lý sản phẩm</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <!-- Animation CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Loading Animation -->
    <div class="loading">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <!-- Header -->
    <div class="header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h2><i class="fas fa-file-export"></i> Xuất báo cáo</h2>
                </div>
                <div class="col-md-6 text-right">
                    <div class="user-info">
                        <span class="mr-2">
                            <i class="fas fa-user"></i> 
                            <?php echo htmlspecialchars($_SESSION['username']); ?>
                        </span>
                        <a href="logout.php" class="btn btn-light btn-sm">
                            <i class="fas fa-sign-out-alt"></i> Đăng xuất
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="card animate__animated animate__fadeIn">
            <div class="card-header">
                <h5><i class="fas fa-file-export"></i> Tùy chọn xuất báo cáo</h5>
            </div>
            <div class="card-body">
                <form method="POST" class="needs-validation" novalidate>
                    <div class="form-group">
                        <label>Loại báo cáo</label>
                        <select name="report_type" class="form-control" required>
                            <option value="">Chọn loại báo cáo</option>
                            <option value="inventory">Báo cáo tồn kho</option>
                            <option value="low_stock">Báo cáo hàng sắp hết</option>
                            <option value="category">Báo cáo theo danh mục</option>
                        </select>
                        <div class="invalid-feedback">
                            Vui lòng chọn loại báo cáo
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Từ ngày</label>
                        <input type="date" name="date_from" class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Đến ngày</label>
                        <input type="date" name="date_to" class="form-control">
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-file-export"></i> Xuất báo cáo
                        </button>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Quay lại
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>